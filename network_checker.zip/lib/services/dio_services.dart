import 'dart:io';

import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:network_checker/controller/controller.dart';

import '../model/post_model.dart';

class DioService {
  Future<List<Post>?> getMethod(String url) async {
    Dio dio = Dio();
    PostController postController = Get.find<PostController>();
    /*   var response = await dio.get(url,
        options: Options(responseType: ResponseType.json, method: "GET"));

    return postFromDynamic(response.data);*/
    try {
      print("netxorllfkkf");
      var response = await dio.get(url,
          options: Options(responseType: ResponseType.json, method: "GET"));

      return postFromDynamic(response.data);
    } on SocketException catch (_) {
      print('not connected');
      postController.isInternetConnect.value = false;
    }
  }
}
