import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:network_checker/utils/colors.dart';

import 'controller/controller.dart';

class Detail extends StatelessWidget {
  Detail({required this.index, super.key});
  int index;

  PostController postController = Get.find<PostController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColors.bgColor,
      appBar: AppBar(
        backgroundColor: MyColors.prColor,
        centerTitle: true,
        title: const Text("Details View"),
      ),
      body: SizedBox(
        width: double.infinity,
        height: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                  color: Colors.grey[700],
                  borderRadius: BorderRadius.circular(7)),
              child: Center(
                  child: Text(postController.posts[index].id.toString(),
                      style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: Colors.black))),
            ),
            const SizedBox(
              height: 15,
            ),
            Text(postController.posts[index].title.toUpperCase(),
                style: const TextStyle(fontWeight: FontWeight.w500),
                textAlign: TextAlign.center),
            const SizedBox(
              height: 15,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(postController.posts[index].body,
                  style: const TextStyle(
                      fontWeight: FontWeight.w500, color: Colors.grey),
                  textAlign: TextAlign.center),
            )
          ],
        ),
      ),
    );
  }
}
