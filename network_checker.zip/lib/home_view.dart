import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:network_checker/detail_view.dart';
import 'package:network_checker/utils/colors.dart';
import 'package:network_checker/utils/constants.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'controller/controller.dart';
import 'package:lottie/lottie.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  PostController postController = Get.put(PostController());
  @override
  Widget build(BuildContext context) {
    postController.getPosts();
    return Scaffold(
      floatingActionButton: Obx(
        () => postController.isInternetConnect.value
            ? FloatingActionButton(
                backgroundColor: MyColors.prColor,
                onPressed: () {
                  postController.isListViewScrollToDown.value
                      ? postController.scrollListViewUpWard()
                      : postController.scrollListViewDownWard();
                },
                child: postController.isListViewScrollToDown.value
                    ? FaIcon(FontAwesomeIcons.arrowUp)
                    : FaIcon(FontAwesomeIcons.arrowDown),
              )
            : Container(),
      ),
      backgroundColor: MyColors.bgColor,
      appBar: _buildAppBar(),
      body: SizedBox(
        width: double.infinity,
        height: double.infinity,
        child: Obx(
          () => postController.isInternetConnect.value
              ? postController.isLoading.value == true
                  ? _buildLoading()
                  : _buildBody()
              : Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 150,
                        height: 150,
                        child: Lottie.asset('assets/no_network.json'),
                      ),
                      MaterialButton(
                          color: MyColors.prColor,
                          child: Text("Try Again",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 12)),
                          onPressed: () async {
                            if (await InternetConnectionChecker()
                                    .hasConnection ==
                                true) {
                              postController.getPosts();
                            } else {
                              showCustomSnackBar(context);
                            }
                          })
                    ],
                  ),
                ),
        ),
      ),
    );
  }

// body
  RefreshIndicator _buildBody() {
    return RefreshIndicator(
      color: MyColors.prColor,
      onRefresh: () {
        return postController.getPosts();
      },
      child: ScrollablePositionedList.builder(
          itemScrollController: postController.itemScrollaController,
          physics: const BouncingScrollPhysics(),
          itemCount: postController.posts.length,
          itemBuilder: (ctx, i) {
            return InkWell(
              onTap: () {
                Get.to(Detail(index: i), transition: Transition.cupertino);
              },
              child: Card(
                child: ListTile(
                  leading: Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                        color: Colors.grey[700],
                        borderRadius: BorderRadius.circular(7)),
                    child: Center(
                        child: Text(postController.posts[i].id.toString())),
                  ),
                  title: Text(postController.posts[i].title),
                  subtitle: Text(
                    postController.posts[i].body.substring(0, 50),
                    style: const TextStyle(fontWeight: FontWeight.w300),
                  ),
                ),
              ),
            );
          }),
    );
  }

//appbar
  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: MyColors.prColor,
      centerTitle: true,
      title: const Text("Restful API - DIO"),
    );
  }

//Loading
  Center _buildLoading() {
    return Center(
        child: SizedBox(
      width: 150,
      height: 150,
      child: Lottie.asset('assets/a.json'),
    ));
  }
}
