import 'package:flutter/animation.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

import '../model/post_model.dart';
import '../services/dio_services.dart';

class PostController extends GetxController {
  RxList<Post> posts = RxList();
  RxBool isLoading = true.obs;
  RxBool isInternetConnect = true.obs;
  RxBool isListViewScrollToDown = false.obs;

  var url = "https://jsonplaceholder.typicode.com/posts";

  var itemScrollaController = ItemScrollController();

  getPosts() async {
    isInternetConnectFunc();
    isLoading.value = true;
    var response = await DioService().getMethod(url);
    posts(response);
    isLoading.value = false;
  }

  isInternetConnectFunc() async {
    isInternetConnect.value = await InternetConnectionChecker().hasConnection;
  }

  scrollListViewDownWard() {
    itemScrollaController.scrollTo(
        index: posts.length - 4,
        duration: Duration(milliseconds: 2000),
        curve: Curves.fastOutSlowIn);
    isListViewScrollToDown.value = true;
  }

  scrollListViewUpWard() {
    itemScrollaController.scrollTo(
        index: 0,
        duration: Duration(milliseconds: 2000),
        curve: Curves.fastOutSlowIn);
    isListViewScrollToDown.value = false;
  }

  @override
  void onInit() {
    isInternetConnectFunc();
    getPosts();
    super.onInit();
  }
}
