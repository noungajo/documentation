import 'package:flutter/cupertino.dart';

class MyColors {
  static const Color bgColor = Color(0xfffaf6f7);
  static const Color prColor = Color(0xffdcf3644);
  static const Color scColor = Color(0xfffffffff);
}
